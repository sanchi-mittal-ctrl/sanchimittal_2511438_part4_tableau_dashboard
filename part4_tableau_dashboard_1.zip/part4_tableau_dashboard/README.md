# Executive Sales Dashboard — Part 4

## Business Problem Summary

Retail leadership needs a single view to monitor sales performance, profitability, customer segments, category performance, shipping performance, discount impact, and return patterns — to identify business opportunities and risks rather than just reviewing raw sales totals. This dashboard is built to answer that need with a small set of focused, decision-oriented views rather than a large collection of disconnected charts.

## Dataset Description

- **File:** `data/dashboard_sales_data.xlsx` (sheet: `dashboard_sales_data`, plus a `data_dictionary` sheet defining each column)
- **Size:** 4,200 orders, 20 fields, covering **January 1, 2024 – December 31, 2025**
- **Geography:** 4 regions (North, South, East, West) across 19 Indian states, 20 cities
- **Field types:**
  - *Date:* `order_date`, `ship_date`
  - *Geographic:* `region`, `state`, `city`
  - *Categorical:* `customer_segment`, `category`, `sub_category`, `product_name`, `ship_mode`, `campaign_channel`
  - *Numerical measures:* `sales`, `quantity`, `discount`, `profit`, `delivery_days`, `customer_rating`
  - *Binary/flag:* `return_flag` (1 = returned, 0 = not returned)
  - *Identifiers:* `order_id`, `customer_id`
- **Scale:** ₹21.70 crore total sales, ₹3.33 crore total profit, 15.3% overall margin, 4.5% overall return rate, ~4,096 unique customers.

## Tableau Workbook Description

`tableau/executive_dashboard.twbx` is structured as one Executive Dashboard sheet built from seven supporting views (see Required Tasks below): Sales Trend, Regional Performance, Category Profitability, Customer Segment, Shipping Performance, Discount vs. Profit, and Return Analysis. Build specifications for each view — including chart type, fields, and design rationale — are documented in `outputs/chart_selection_justification.md`.

*Status note: the analytical content of this dashboard (calculated fields, view designs, insights, and narrative) is fully specified and data-grounded below. The actual `.twbx` file build and screenshot capture happen in Tableau Desktop and are tracked as the remaining step — see "Screenshots Included" below.*

## Calculated Fields Created

| Field | Formula (Tableau syntax) | Logic |
|---|---|---|
| **Profit Margin** | `SUM([profit]) / SUM([sales])` | Aggregated ratio (not row-level average) so it's not distorted by very small orders. |
| **Cost** | `[sales] - [profit]` | Implied cost per order line, since cost isn't a source field. |
| **Average Order Value** | `SUM([sales]) / COUNTD([order_id])` | Each row is already one order, so this gives sales per order (not per customer). |
| **Return Rate** | `SUM([return_flag]) / COUNTD([order_id])` | Share of orders flagged as returned. |
| **Shipping Delay Bucket** | `IF [delivery_days] <= 1 THEN "0-1 days (Fast)" ELSEIF [delivery_days] <= 3 THEN "2-3 days (Standard)" ELSEIF [delivery_days] <= 5 THEN "4-5 days (Slow)" ELSE "6+ days (Very Slow)" END` | Bucket boundaries chosen from the actual distribution (median 4 days, IQR 2–5 days), not arbitrary round numbers. |
| **Discount Tier** *(additional)* | `IF [discount] = 0 THEN "0% (No Discount)" ELSEIF [discount] <= 0.15 THEN "5-15%" ELSEIF [discount] <= 0.25 THEN "20-25%" ELSE "30-35%" END` | Matches the dataset's actual discrete discount levels (0%, 5%, 10%...35%). |
| **Profit per Order** *(additional)* | `SUM([profit]) / COUNTD([order_id])` | Useful KPI card alongside AOV. |

## Dashboard Components

- **KPI cards:** Total Sales, Total Profit, Overall Profit Margin, Overall Return Rate (4 cards, exceeds the minimum of 3)
- **Charts/views:** 7 supporting views (exceeds the minimum of 5) — see Tableau Workbook Description above
- **Filters:** Region, Category, Customer Segment, Date Range (Year/Month), Ship Mode (5 filters, exceeds the minimum of 3)
- **Action/interaction:** Dashboard filter action — clicking a region on the map filters the Category Profitability and Return Analysis views to that region

## Filters and Interactions Used

All charts are connected to the global filters above. The Region map acts as a filter source: selecting a state/region narrows every other view on the dashboard to that geography, so leadership can drill from "which region" straight into "which category/segment is driving that region's numbers" without switching sheets.

## Key Business Insights

Full detail with evidence and recommended actions is in `outputs/business_insights.md`. Headline findings:
- Technology drives 84.2% of profit from 70.9% of sales (18.2% margin) — the clear profit engine.
- Furniture drags profitability: 23.8% of sales but only 10.7% of profit (6.9% margin), and the highest return rate (7.7%).
- Margin declines steadily with discount, turning **negative (−5.0%) at the 35% discount tier**.
- Shipping delay does **not** show a meaningful relationship with return rate in this data (41–51% flat across delay buckets) — contrary to a common assumption.
- Returns are concentrated, not uniform: Furniture × Home Office (9.1%) and Furniture × East region (9.8%) are the worst combinations.

## Dashboard Story Summary

Full narrative is in `outputs/dashboard_story.md`. In short: the business is profitable and modestly growing (+4.3% YoY sales), but profitability is concentrated in Technology while Furniture and unmanaged high-discount orders are quietly eating into margin. The recommended near-term actions are a Furniture pricing/return review and a discount approval ceiling around 25–30%.

## Assumptions and Limitations

- Currency is assumed to be Indian Rupees (₹) based on state geography in the data; not explicitly labeled in the source file.
- `campaign_channel` (24 missing) and `customer_rating` (32 missing) values are excluded from channel/rating-specific views rather than imputed — together under 1% of rows.
- `delivery_days` is taken as provided (ship date minus order date) without separating weekends/holidays from business days.
- There is no return-reason field, so all return-driver conclusions (category, segment, region) are correlational, not causal.
- Two years of history limits confidence in distinguishing real seasonality from short-term noise in the sales trend.

## Screenshots Included

The following screenshots are required and should be captured directly from the built Tableau dashboard once `tableau/executive_dashboard.twbx` is finalized:
- `screenshots/full_dashboard.png`
- `screenshots/sales_trend_view.png`
- `screenshots/regional_performance_view.png`
- `screenshots/category_profitability_view.png`
- `screenshots/filter_interaction_view.png` (capture with a filter actively applied, e.g. a region selected, to show the interaction taking effect)
