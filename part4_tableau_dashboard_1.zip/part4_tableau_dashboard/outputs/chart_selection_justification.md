# Chart Selection Justification

This document explains the chart type chosen for each required view, the design logic behind it, and the visualization mistake each choice avoids. Use this as the build spec when constructing each sheet in Tableau — if you adjust a field/encoding while building, update the relevant entry so it stays accurate to the final workbook.

---

### 1. Sales Trend View

- **Question answered:** How is sales (and profit) changing month over month across 2024–2025?
- **Chart type:** Line chart, `order_date` (continuous, monthly) on Columns, `SUM(sales)` on Rows, with a secondary line/axis for `SUM(profit)`.
- **Encoding:** Color = measure (Sales vs. Profit, two lines); Label = optional value labels on hover only, not on every point, to avoid clutter.
- **Design principle applied:** Line charts are the correct choice for time-series trend — they preserve the sense of continuous change that a bar chart would chop into disconnected blocks.
- **Mistake avoided:** Not truncating the Y-axis to exaggerate the trend (axis starts at 0), and not using a bar chart for 24 months of data, which would create visual noise without showing trajectory clearly.

---

### 2. Regional Performance View

- **Question answered:** Which regions/states drive the most sales and profit, and how does margin compare across them?
- **Chart type:** Filled map (state-level, colored by `Profit`) paired with a horizontal bar chart of `SUM(sales)` by region, sorted descending.
- **Encoding:** Color = Profit (sequential, single-hue, not red-green diverging since there are no negative-profit states); Size/label on map = Sales; Filter = Region.
- **Design principle applied:** Geographic data benefits from a map for spatial pattern recognition, paired with a sorted bar chart for precise ranking — maps are good for "where," bars are better for "how much, exactly."
- **Mistake avoided:** Avoided a default red-to-green diverging color scale (implies "bad vs. good" when margins are actually all positive and close together — true range is 14.1%–16.6%); used a single sequential palette instead so color differences reflect the real, modest spread.

---

### 3. Category Profitability View

- **Question answered:** Which categories and sub-categories drive profit vs. consume sales without returning profit?
- **Chart type:** Horizontal bar chart of `Profit Margin` by category and sub-category, sorted by margin ascending so the weakest performers are immediately visible.
- **Encoding:** Color = Category (categorical, 3 colors only); Label = Profit Margin %; secondary bar/Gantt overlay optional for Sales for context.
- **Design principle applied:** Sorting by the actual metric of interest (margin, not alphabetical) creates immediate hierarchy — the worst performers (Tables, Bookcases) are visually first.
- **Mistake avoided:** Avoided a pie chart or treemap as the *primary* margin view — area-based charts are good for "share of total" but poor for precise comparison of a ratio like margin; reserved treemap (if used) for sales-share context only, not for margin comparison.

---

### 4. Customer Segment View

- **Question answered:** How do Consumer, Corporate, and Home Office segments compare on margin, return rate, and order value?
- **Chart type:** Side-by-side bar chart (small multiples) — one bar chart per metric (Margin %, Return Rate %, AOV), segment on the axis of each.
- **Encoding:** Color = Segment (consistent color per segment across all three small charts); Label = value on each bar.
- **Design principle applied:** Consistent color-per-category across multiple small charts lets leadership track "Home Office" visually across all three metrics without re-reading legends.
- **Mistake avoided:** Avoided cramming all three metrics onto one dual/triple-axis chart, which would force mismatched scales (percentages vs. rupee values) onto the same axis and distort comparison.

---

### 5. Shipping Performance View

- **Question answered:** Which shipping modes are slowest, and does delivery delay relate to returns?
- **Chart type:** Bar chart of average `delivery_days` by `ship_mode`, plus a second bar chart of `Return Rate` by `Shipping Delay Bucket`.
- **Encoding:** Color = Ship Mode; Label = average days / return rate %; Filter = Ship Mode, Region.
- **Design principle applied:** Two focused bar charts (one per question) rather than one overloaded combination chart — keeps each comparison readable on its own scale.
- **Mistake avoided:** Avoided implying a delay→return causal relationship visually (e.g., via a misleading trend line) when the underlying data is actually flat (41–51% return rate across all delay buckets) — the chart should show the flatness honestly, not force a story onto it.

---

### 6. Discount vs. Profit View

- **Question answered:** How does discount level relate to profit margin, and at what point does discounting stop being profitable?
- **Chart type:** Scatter plot — `discount` on X, `profit` (or `Profit Margin`) on Y, one mark per order; reference line at Profit = 0.
- **Encoding:** Color = Category (to see if the effect differs by category); Size = Sales (optional); a zero-reference line clearly separates profitable from loss-making orders.
- **Design principle applied:** Scatter plots are the correct chart for showing the relationship between two continuous variables at the individual-order level — a bar chart of discount "buckets" (used elsewhere for summary) would hide the order-level spread and the loss-making cluster at high discount.
- **Mistake avoided:** Avoided trend-line-only presentation without showing the underlying point cloud — leadership should be able to see that the 35% discount tier isn't just "lower average margin" but genuinely contains loss-making orders.

---

### 7. Return Analysis View

- **Question answered:** Where are returns concentrated — which category, segment, or region has the highest return risk?
- **Chart type:** Highlight table (heat-map style grid) of Return Rate by Category × Customer Segment, with color intensity = return rate.
- **Encoding:** Color = Return Rate (sequential, light-to-dark, single hue); Label = return rate %; Filter = Region.
- **Design principle applied:** A highlight table is well suited to a two-dimensional categorical comparison (category × segment) — it lets leadership scan for the darkest cell (Furniture × Home Office, 9.1%) immediately, which a set of separate bar charts would not surface as clearly.
- **Mistake avoided:** Avoided a 3D or donut-style return chart, and avoided color scales that go all the way to red for a 9% rate — using a moderate, proportionate color intensity keeps the visual honest about the actual magnitude (return rates here range roughly 2%–9%, not 0–100%).

---

### General Dashboard-Level Principles Applied

- **Consistent color mapping:** Category and Segment use the same color-to-value mapping on every sheet they appear in, so leadership doesn't have to re-learn the legend per chart.
- **Sorting:** Every bar chart is sorted by its measure (not alphabetically) so the most/least important items are immediately visible.
- **No 3D, no dual-axis trickery, no truncated axes:** chosen deliberately to keep every comparison visually honest.
- **KPI cards** for Total Sales, Total Profit, Overall Margin (or Return Rate) sit at the top of the dashboard so leadership gets the headline numbers before drilling into any single chart.
