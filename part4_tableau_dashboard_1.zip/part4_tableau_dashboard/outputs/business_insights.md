# Business Insights — Executive Dashboard

Dataset: `dashboard_sales_data.xlsx` | 4,200 orders | Jan 2024 – Dec 2025 | 19 Indian states, 4 regions
All figures below are computed directly from the dataset (totals, not estimates).

---

### 1. Sales Trend

**Observation:** Monthly sales are volatile rather than steadily growing. Total sales were ₹10.62 crore in 2024 vs. ₹11.08 crore in 2025 — a modest ~4.3% YoY increase, not a strong growth trend.

**Data evidence:** Monthly sales swing between ₹63.0 lakh (Aug 2024, the weakest month) and ₹1.086 crore (Aug 2025, the strongest month). The second half of 2025 (Jul–Nov) is consistently strong (₹1.01–1.09 crore/month), while mid-2024 and mid-2025 both show a dip (Apr–Aug).

**Business interpretation:** The business isn't on a clear upward trajectory — recent strength looks more like a seasonal H2 pattern than sustained growth. Relying on a "growth" narrative without examining seasonality would overstate momentum.

**Recommended action:** Investigate what drove the Jul–Nov 2025 surge (campaign timing, festive-season demand, new product lines) and test whether it's repeatable; build a seasonal forecast rather than a flat growth target.

---

### 2. Regional Performance

**Observation:** South region leads on absolute sales (₹6.47 crore) and profit (₹99.9 lakh), but profit margin is essentially flat across all four regions (15.1%–15.6%).

**Data evidence:** Region totals — South: ₹6.47cr sales / 15.4% margin; North: ₹5.46cr / 15.2%; East: ₹4.89cr / 15.6%; West: ₹4.89cr / 15.1%. At the state level, Rajasthan is the top profit contributor (₹32.8 lakh) while Odisha is the lowest (₹11.7 lakh).

**Business interpretation:** Regional differences are driven by sales volume, not by underlying profitability — no region is structurally more or less efficient. This means regional growth investment is a volume play, not a margin-fix play.

**Recommended action:** Prioritize demand-generation spend in West and East (lowest absolute profit despite comparable margin) rather than margin interventions; study what Rajasthan/South are doing right in terms of product mix or campaign reach.

---

### 3. Category & Sub-Category Profitability

**Observation:** Technology generates 70.9% of sales but 84.2% of total profit — it is by far the most efficient category (18.2% margin). Furniture is the weak point: 23.8% of sales but only 10.7% of profit (6.9% margin).

**Data evidence:** Technology: ₹15.39cr sales, 18.2% margin. Office Supplies: ₹1.15cr sales, 14.9% margin. Furniture: ₹5.16cr sales, 6.9% margin — and within Furniture, Tables (5.7% margin) and Bookcases (5.7%) are barely above break-even.

**Business interpretation:** Furniture is consuming a meaningful share of sales effort and inventory for very little profit return, while Technology is doing the heavy lifting on profitability.

**Recommended action:** Review Furniture pricing/cost structure (especially Tables and Bookcases) — determine if margin can be improved or if SKU rationalization is warranted. Double down on Technology assortment and marketing given its outsized profit contribution.

---

### 4. Customer Segment Behavior

**Observation:** Profit margin is nearly identical across segments (Consumer 15.3%, Corporate 15.2%, Home Office 15.5%), but Home Office has a noticeably higher return rate.

**Data evidence:** Return rate — Home Office: 5.67%, Corporate: 4.00%, Consumer: 3.91%. Average order value is also lowest for Home Office (₹51,522) vs. Consumer (₹53,053).

**Business interpretation:** Home Office customers behave differently post-purchase (more returns) despite ordering similar-margin products at a slightly lower basket size — worth understanding whether this is a product-fit issue or a different buying context (e.g., home delivery damage, indecisive purchasing).

**Recommended action:** Segment-specific return-reason analysis for Home Office orders, particularly cross-referenced with Furniture (see Insight 7) where the combination is worst.

---

### 5. Discount Impact on Profit

**Observation:** There is a clean, strong, negative relationship between discount level and profit margin — margin erodes steadily as discount increases, and the highest discount tier sells at a loss on average.

**Data evidence:** Margin by discount level: 0% → 20.6% margin; 5% → 18.1%; 10% → 15.8%; 15% → 14.1%; 20% → 13.2%; 25% → 8.6%; 30% → 7.6%; **35% → −5.0% margin** (64 orders, genuinely loss-making on average). Row-level correlation between discount and margin is −0.60.

**Business interpretation:** Discounting beyond ~25% is not just "lower margin" — at the 35% tier the company is losing money on the average order. This is a real, quantifiable risk, not a marginal effect.

**Recommended action:** Set or enforce a discount approval ceiling (e.g., flag/require approval above 25%); audit who/what is driving 30–35% discounts (specific reps, channels, or SKUs) and whether it's actually moving incremental volume that justifies the margin loss.

---

### 6. Shipping / Delivery Performance

**Observation:** Standard Class is by far the dominant shipping mode (58% of orders) and also the slowest (avg. 4.71 days). However, delivery speed does **not** show a clear relationship with return rate in this data.

**Data evidence:** Return rate by delivery-time bucket: 0–1 days: 4.3%; 2–3 days: 5.1%; 4–5 days: 4.1%; 6+ days: 4.8% — essentially flat, not increasing with delay. Same-Day shipping has the lowest return rate (2.5%) but is a small share of orders (241).

**Business interpretation:** The common assumption that "slower shipping causes more returns" isn't supported here — return drivers appear to sit elsewhere (category/segment, per Insights 3–4), not delivery speed. This is worth stating explicitly so leadership doesn't chase the wrong lever.

**Recommended action:** Don't prioritize delivery-speed investment as a return-reduction tactic based on this data; if returns are the priority, focus on Furniture quality/fit and Home Office segment experience instead. Re-test this relationship once return-reason data is available.

---

### 7. Return Patterns

**Observation:** Overall return rate is 4.5%, but it is heavily concentrated: Furniture is nearly double the average, and the worst combination is Furniture + Home Office.

**Data evidence:** Return rate by category: Furniture 7.67%, Office Supplies 3.65%, Technology 3.03%. Worst cross-cuts: Furniture × Home Office = 9.14% (405 orders); East region × Furniture = 9.77%. Within Furniture, Bookcases (8.4%) and Furnishings (8.2%) are the highest sub-category return rates.

**Business interpretation:** Returns are not a general problem — they're a specific, addressable one: a particular category, in a particular segment, in a particular region.

**Recommended action:** Run a targeted root-cause review on Furniture returns in the East region and for Home Office buyers specifically (e.g., product description accuracy, packaging/damage, sizing expectations) before investing in a company-wide return-reduction program.

---

### 8. Business Risk & Opportunity Summary

**Observation (Risk):** Furniture combines below-average margin (6.9%), above-average returns (7.67%), and meaningful sales share (23.8%) — it's a structural drag on profitability, not a minor issue.

**Observation (Opportunity):** Technology is both the profit engine (84.2% of total profit) and has the lowest return rate (3.03%) — there's clear room to grow it further with confidence in its unit economics. Separately, capping discounts above 25–30% is a low-effort, high-confidence margin protection lever (see Insight 5).

**Data evidence:** See Insights 3, 5, and 7 above for the supporting figures.

**Recommended action / follow-up question:** Should Furniture be repriced, reformulated, or deprioritized in marketing spend relative to Technology? And: what is actually driving the 30–35% discount tier — is it a deliberate clearance strategy or an unmanaged discretionary practice?
