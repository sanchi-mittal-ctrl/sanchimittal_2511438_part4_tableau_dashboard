# Executive Dashboard Story

*Prepared for: Retail Leadership Team*
*Period covered: January 2024 – December 2025*

## Executive Summary

Across the last two years, the business generated ₹21.70 crore in sales at a 15.3% overall profit margin, across 4,200 orders and roughly 4,100 unique customers. Growth has been modest (~4.3% sales increase from 2024 to 2025) rather than dramatic, and profitability is heavily concentrated: one category and a handful of discount decisions explain most of the margin story. The dashboard is built to help leadership see past category-level revenue numbers and into *where* the company is actually making and losing money.

## What Is Performing Well

**Technology is carrying the business.** It accounts for 70.9% of sales but 84.2% of total profit, at an 18.2% margin — the strongest of the three categories — and it also has the lowest return rate (3.0%). The South region and Rajasthan/Telangana/Karnataka lead on absolute profit contribution. Same-Day shipping, while a small share of volume, has the lowest return rate of any shipping mode (2.5%), suggesting fast fulfillment isn't a liability when it's used.

## What Is Underperforming

**Furniture is a profitability drag.** It represents 23.8% of sales but only 10.7% of profit, at a 6.9% margin — less than half the company average — with Tables and Bookcases sitting close to break-even (~5.7% margin). It also carries the highest return rate of any category (7.7%), nearly double the company average. This isn't a small effect: Furniture is the single biggest gap between "share of sales" and "share of profit" in the business.

**High discounting is actively destroying margin.** Margin declines steadily and predictably as discount increases — from 20.6% at 0% discount down to a **loss-making −5.0% margin at the 35% discount tier**. This is one of the clearest, most actionable patterns in the data.

## Risks Visible in the Data

1. **Concentration risk in Furniture** — a quarter of sales sitting at break-even-or-worse margin, with elevated returns, is a structural weak point rather than a one-off.
2. **Unmanaged discount creep** — the 30–35% discount tier (≈14% of all orders) is, on average, unprofitable. If this is discretionary (not a deliberate clearance strategy), it's quietly eroding overall profit.
3. **Concentrated return pattern** — Furniture purchased by Home Office customers (9.1% return rate) and Furniture in the East region (9.8%) are notably worse than the company average, suggesting a specific, fixable cause rather than a general quality problem.

## Opportunities Visible in the Data

1. **Double down on Technology** — it's already the profit engine and has the best return performance; incremental marketing or assortment investment here has the most de-risked upside.
2. **Discount governance** — capping or requiring approval above ~25% discount is a low-cost, high-confidence way to protect margin without touching volume strategy.
3. **Targeted (not company-wide) return reduction** — because returns are concentrated in Furniture/Home Office/East rather than spread evenly, a focused investigation could meaningfully move the overall return rate without a broad, expensive initiative.

## Recommended Business Actions

- Commission a focused review of Furniture pricing, cost structure, and return causes (especially Tables, Bookcases, Furnishings).
- Introduce a discount approval threshold around 25–30%, and audit what is currently driving orders into the 30–35% tier.
- Investigate the Jul–Nov 2025 sales surge to determine if it's a repeatable seasonal pattern worth planning around, or a one-time event.
- Re-route returns analysis away from shipping speed (the data does not support a delay → return relationship) and toward category/segment/region drivers instead.

## Limitations of the Dashboard

- The dataset has no explicit "return reason" field, so return-driver conclusions here are correlational (category, segment, region), not causal.
- `campaign_channel` and `customer_rating` have a small number of missing values (~0.6–0.8% of rows); these are excluded from channel/rating-specific views rather than imputed.
- Two years of data limits the ability to distinguish genuine seasonality from short-term noise in the sales trend.
- Currency/units are assumed to be Indian Rupees (₹) based on the state geography, but this is not explicitly labeled in the source file.

## Suggested Next Analysis

- A return-reason or product-defect tagging exercise for Furniture, to move from correlation to root cause.
- A discount-elasticity study: does the 30–35% tier actually drive incremental volume that offsets the margin loss, or could the same volume be captured at a lower discount?
- A cohort/retention view by customer segment and campaign channel, to see whether acquisition channel quality differs (currently out of scope for this dashboard).
